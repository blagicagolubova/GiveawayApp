create materialized view most_participants as
SELECT g.id,
       g.creator_username,
       count(gp.*) AS count
FROM giveaway g
         LEFT JOIN giveaway_participants gp ON g.id = gp.giveaway_id
WHERE g.status::text ~~ 'ACTIVE'::character varying::text
GROUP BY g.id, g.creator_username
ORDER BY (count(gp.*)) DESC;

alter materialized view most_participants owner to postgres;

